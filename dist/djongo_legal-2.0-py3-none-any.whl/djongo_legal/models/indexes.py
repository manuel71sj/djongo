# This version of djongo_legal does not support indexes
